# Muddasar Iqbal Portfolio

Static site: no build step, no dependencies, no tracking.

## Structure
- index.html (all HTML, CSS, JS)
- assets/muddasar.jpg, assets/Muddasar_Iqbal_Resume.pdf

## Publish (free)
**Netlify (fastest):** go to app.netlify.com/drop and drag this folder in. You get a public URL immediately; rename it under Site settings.
**GitHub Pages:** create a repo, upload these files, then Settings > Pages > Deploy from branch > main / root. URL: https://USERNAME.github.io/REPO/
**Vercel:** import the repo, framework "Other", no build command.

## Custom domain
Buy a domain, add it in your host's Domains settings, then create the DNS records it shows (usually an A record or CNAME for www). HTTPS is issued automatically.

## Before sharing
Confirm the resume PDF is the version you want public (it names Furnishion; the site itself stays anonymous). Consider replacing it with an anonymized copy.
